
public enum CellType {
    Red,
    Black,
    Empty,
    None
    

}
